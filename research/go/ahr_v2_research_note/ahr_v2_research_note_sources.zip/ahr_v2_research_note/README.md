# AHR v2 Go research note

This project reconstructs the promising teacher-trained AHR v2 player and its recorded development results. No training or live engine inference was performed for the note.

## Compile the paper

Open `main.tex` in a LaTeX editor, or run `tectonic -X compile main.tex` from this directory. TikZ diagrams are editable sources in `figures/`; the statistical plots are included as vector PDFs. No shell escape or bibliography service is required.

## Reproduce the statistical figures

Install `requirements.txt` into a local Python environment. Open `analysis.ipynb`, select that environment's kernel, set this project as the working directory, and run all cells. The notebook kernel name records the authoring environment; select your own compatible Python kernel when it is unavailable. Runtime is under one minute on CPU. It checks copied evidence hashes, counts and denominators; recomputes nominal Wilson intervals; and regenerates the PDF/PNG plots and derived CSV. No long run or checkpoint is required.

## Evidence and interpretation

`evidence/source_manifest.json` identifies copied recovered records and notebook definition hashes. `benchmark_breakdown_recovered.json` preserves the original retained diagnostic output and its provenance; the full benchmark game trace itself was unavailable. `plot_validation.json` records the computational checks. Preliminary reviews use 128 fixed simulations; the larger benchmark uses a soft two-second budget and 512-simulation cap. The protocols are kept separate. Wilson intervals are descriptive because games share openings and can repeat trajectories.

The source bundle does not include the trained checkpoint tensor payload or prepared training arrays. Their recorded identities support provenance, not reconstruction from hashes alone. The note cannot be used as evidence of a fresh rerun, hard real-time deadlines, general AHR superiority, or whole-game optimality.
